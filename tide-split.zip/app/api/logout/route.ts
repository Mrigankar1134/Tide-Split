import { NextResponse } from "next/server";
import { clearSession } from "@/lib/auth";
export const dynamic = "force-dynamic";
export async function POST() { return clearSession(NextResponse.json({ ok: true })); }
